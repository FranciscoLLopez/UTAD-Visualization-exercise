package geocode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import static java.nio.charset.StandardCharsets.*;

public class principal {
	static ReverseGeoCode reverseGeoCode;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			reverseGeoCode = new ReverseGeoCode(new FileInputStream("d:\\allCountries.txt"), true);
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader("D:\\entrada_coord.txt"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// Guardamos los cambios del fichero
		try {
			leeFichero(br);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}

	public static void leeFichero(BufferedReader br) throws IOException {
		// Leemos el fichero y lo mostramos por pantalla
		String linea = br.readLine();
		BufferedWriter bw = new BufferedWriter(new FileWriter("D:\\salida_coord.txt"));

		int contador = 0;
		while (linea != null) {
			String[] coord = linea.split("\t");
			String lat = "";
			String lon = "";
			lat = coord[0].replaceAll(",", ".");
			lon = coord[1].replaceAll(",", ".");
			contador++;
			GeoName salida = reverseGeoCode.nearestPlace(
					Double.parseDouble(lat), Double.parseDouble(lon));

			byte ptext[] = salida.toString().getBytes(ISO_8859_1);
			String value = new String(ptext, UTF_8);
			String cadena = contador + "\t" + lat + "\t" + lon + "\t" + value+"\n";
			System.out.println(cadena);
			bw.write(cadena);
			bw.flush();
			linea = br.readLine();
		}
		bw.close();
	}

}
